The simple module with stack container

The stack object is based on single linked list