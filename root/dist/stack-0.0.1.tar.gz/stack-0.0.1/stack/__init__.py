__version__ = "0.0.1"
try:
    from _stack import Stack
except ImportError:
    pass
